$(window).on('load', function() {
	var walletAbi = [
		{
			"constant": true,
			"inputs": [
				{
					"name": "wallet",
					"type": "address"
				}
			],
			"name": "ask_balance",
			"outputs": [
				{
					"name": "",
					"type": "uint256"
				}
			],
			"payable": false,
			"stateMutability": "view",
			"type": "function"
		},
		{
			"constant": false,
			"inputs": [
				{
					"name": "wallet",
					"type": "address"
				},
				{
					"name": "amount",
					"type": "uint256"
				}
			],
			"name": "pay",
			"outputs": [],
			"payable": false,
			"stateMutability": "nonpayable",
			"type": "function"
		},
		{
			"constant": false,
			"inputs": [
				{
					"name": "wallet",
					"type": "address"
				}
			],
			"name": "initialize",
			"outputs": [],
			"payable": false,
			"stateMutability": "nonpayable",
			"type": "function"
		},
		{
			"inputs": [],
			"payable": false,
			"stateMutability": "nonpayable",
			"type": "constructor"
		}
	];

    var contractAbi = [
		{
			"constant": false,
			"inputs": [],
			"name": "call",
			"outputs": [],
			"payable": false,
			"stateMutability": "nonpayable",
			"type": "function"
		},
		{
			"constant": false,
			"inputs": [
				{
					"name": "ewz_adr",
					"type": "address"
				},
				{
					"name": "energy_wallets_adr",
					"type": "address"
				}
			],
			"name": "set_addresses",
			"outputs": [],
			"payable": false,
			"stateMutability": "nonpayable",
			"type": "function"
		},
		{
			"constant": false,
			"inputs": [
				{
					"name": "pay_amount",
					"type": "uint256"
				}
			],
			"name": "pay_to_ewz",
			"outputs": [],
			"payable": false,
			"stateMutability": "nonpayable",
			"type": "function"
		},
		{
			"constant": false,
			"inputs": [
				{
					"name": "adr",
					"type": "address"
				},
				{
					"name": "_amount",
					"type": "uint256"
				}
			],
			"name": "pay_user",
			"outputs": [],
			"payable": false,
			"stateMutability": "nonpayable",
			"type": "function"
		},
		{
			"inputs": [],
			"payable": false,
			"stateMutability": "nonpayable",
			"type": "constructor"
		}
	];

    // Checking if Web3 has been injected by the browser (Mist/MetaMask)
    if (typeof web3 !== 'undefined') {
        // Use Mist/MetaMask's provider
        //$('#log').text('I have web3!!!');
        window.web3 = new Web3(web3.currentProvider);
    } else {
        var errorMsg = 'I doesn\'t have web3 :( Please open in Google Chrome Browser and install the Metamask extension.';
        $('#content').text(errorMsg);
        console.log(errorMsg);
        return;
    }
    
	// create instance of contract object that we use to interface the smart contract
	var wallet = web3.eth.contract(walletAbi).at("0x2c51410d5a7f35d043efe13aec1d50f6f69501ec");
	var contractInstance;
	function loadAbi() {
		contractInstance = web3.eth.contract(contractAbi).at($('#address').val());
	}
	
	$('#ewz').on('submit', function(e) {
		e.preventDefault();
		loadAbi();
		contractInstance.pay_to_ewz(parseInt($('#amount').val()), function(error) {});
	});

	$('#dest').on('submit', function(e) {
		e.preventDefault();
		loadAbi();
		contractInstance.pay_user($('#destination').val(), parseInt($('#amount').val()), function(error) {});
	});

	$('#check').on('submit', function(e) {
		e.preventDefault();
		loadAbi();
		wallet.ask_balance($('#address').val(), function(error, value) {
			$('#log').text("Tokens: " + value);
		});
	});
	
});