$(window).on('load', function() {
    
    var contractAddress = "0x2c1032a1496640808c63535e79f6cfbfecb4947a"; // in Ropsten testnet!
    var contractAbi = [
	{
		"constant": false,
		"inputs": [
			{
				"name": "user",
				"type": "address"
			},
			{
				"name": "amount",
				"type": "uint256"
			}
		],
		"name": "pay_user",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "user",
				"type": "address"
			},
			{
				"name": "amount",
				"type": "uint256"
			}
		],
		"name": "user_sold_tokens_to_ewz",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "ewz_adr",
				"type": "address"
			}
		],
		"name": "set_addresses",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "constructor"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"name": "user",
				"type": "address"
			},
			{
				"indexed": false,
				"name": "amount",
				"type": "uint256"
			}
		],
		"name": "event_user_sold_tokens_to_ewz",
		"type": "event"
	}
];

    // Checking if Web3 has been injected by the browser (Mist/MetaMask)
    if (typeof web3 !== 'undefined') {
        // Use Mist/MetaMask's provider
        $('#content').text('I have web3!!!');
        window.web3 = new Web3(web3.currentProvider);
    } else {
        var errorMsg = 'I doesn\'t have web3 :( Please open in Google Chrome Browser and install the Metamask extension.';
        $('#content').text(errorMsg);
        console.log(errorMsg);
        return;
    }
    
    // create instance of contract object that we use to interface the smart contract
    var contractInstance = web3.eth.contract(contractAbi).at(contractAddress);

	var event = contractInstance.event_user_sold_tokens_to_ewz();
	
	// Catch the event from the oracle and set $('#log')

	var log = "";

    event.watch(function(error, result){
		if (error) {
			$('#log').text('Error: ' + error);
		} else {
			log += result.args.user + ' sold ' + result.args.amount + ' tokens.\n';
			$('#log').text(log);
		}
	});
	
	$('#my-form').on('submit', function(e) {
		e.preventDefault();
		contractInstance.pay_user($('#address').val(), parseInt($('#amount').val()), function(error) {});
	});
});